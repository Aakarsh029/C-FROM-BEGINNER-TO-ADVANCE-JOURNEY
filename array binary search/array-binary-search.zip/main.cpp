#include <iostream>
using namespace std;

          
int binary_search(int a[],int n,int key)
{
  int s=0,mid;
 int end=n-1;
 
 while(s<=end)
 {
   mid=(s+end)/2;
   
   if(key==a[mid])
   {
    return mid; 
   }
   else
   if(key<a[mid])
    {
      end=mid-1;
    }
   else
     s=mid+1;
   
 }
 return -1;
}  

 
int main()
{
 int n,a[50],z;
 cout<<"enter no of elemts you want in array less than or equal to 50"<<endl;
 cin>>n;
 cout<<"enter the elements of the array"<<endl;
 for(int i=0;i<n;i++) 
 {
   cin>>a[i];
 }
 cout<<"enter the element you want to search in array"<<endl;
 int key;
 cin>>key;
 z=binary_search(a,n,key);
 cout<<"the position of the element you are finding ="<<z+1<<endl;

 return 0;
}
 
